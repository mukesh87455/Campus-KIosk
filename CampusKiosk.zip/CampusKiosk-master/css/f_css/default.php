<html>
<head>
<title>KIET</title>
</head>

<body>
    <link rel="stylesheet" type="text/css" href="../css/s_css/entry.css">

    <div id="tagline">
    	We are not telling you,<br>its going to be easy.<br>
		We are telling you,<br>its going to be worth it.
		
    </div>
        
    <div >
	
    </div>

</div><!--end of content -->
</body>
</html>
