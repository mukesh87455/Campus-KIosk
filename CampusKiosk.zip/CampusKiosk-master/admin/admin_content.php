<html>
<head>
<title>KIET</title>
</head>

<body>
<div id="content">
       
    <div id="tagline">
	<br>
<br><br>
<br><br>
<center>
    <h2>Welcome to</h2><br>
    <h1>Kalam Institute of Engineering and technology</h1>
</center>
<br><br>
<br><br>
<br><br><br><br>

    </div>
        
    <div >
	
    </div>

</div><!--end of content -->
</body>
</html>
